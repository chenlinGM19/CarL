package com.iflytek.autofly.voicecore.aidl;
import com.iflytek.autofly.voicecore.aidl.IRecListener;
import com.iflytek.autofly.voicecore.aidl.VoiceServiceId;

/**
 * 录音服务接口
 * 
 * @author admin
 * 
 */
interface IRecSvc {
	/**
	 * 创建一个录音实例
	 * @return
	 */
	int createRecSession(in VoiceServiceId id, IRecListener mRecListener);

	/**
	 * 开启一次录音
	 * @param dataType 音频类型
	 * @return
	 */
	int sessionStart(in VoiceServiceId id, int dataType);

	/**
	 * 结束一次录音
	 * 
	 * @return
	 */
	int sessionStop(in VoiceServiceId id);
	/**
	 * 销毁一个录音实例
	 * 
	 * @return
	 */
	int destroyRecSession(in VoiceServiceId id, IRecListener mRecListener);
}
