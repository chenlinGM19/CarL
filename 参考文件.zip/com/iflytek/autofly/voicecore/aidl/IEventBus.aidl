// IEventBus.aidl
package com.iflytek.autofly.voicecore.aidl;

// Declare any non-default types here with import statements

import com.iflytek.autofly.voicecore.aidl.IMessage;
import com.iflytek.autofly.voicecore.aidl.platform.IAudioFocusManager;
import com.iflytek.autofly.voicecore.aidl.platform.ILocationManager;
import com.iflytek.autofly.voicecore.aidl.platform.IRecordStatusManager;
import com.iflytek.autofly.voicecore.aidl.platform.IAppStore;
import com.iflytek.autofly.voicecore.aidl.platform.INLPProtocolConvert;

interface IEventBus {
    /**
     * 订阅消息
     * @param [mainType] 消息主类型
     * @param [minorType] 消息次类型
     * @param [mode] 订阅模式：系统独占、应用独占、普通订阅
     * @param [IMessage] 订阅者
     * @return int status
     * <p>created at 2017/3/15 15:47
     */
    int subscribeMessage(String mainType, String minorType, String mode, IMessage subscriber);

    /**
     * 取消订阅消息
     * @param [mainType] 消息主类型
     * @param [minorType] 消息次类型
     * @param [mode] 订阅模式：系统独占、应用独占、普通订阅
     * @param [IMessage] 订阅者
     * @return int status
     * <p>created at 2017/3/15 15:47
     */
    int unSubscribeMessage(String mainType, String minorType, String mode, IMessage subscriber);

    /**
     * 上传消息
     * @param [mainType] 消息主类型
     * @param [minorType] 消息次类型
     * @param [String] 消息体in Json
     * @return int status
     * <p>created at 2017/3/15 15:47
     */
    int postMessage(String mainType, String minorType, in String message);

    /**
     * 获取音频焦点管理实现
     * @return IAudioFocusManager 音频焦点实现
     * <p>created at 2017/5/09 08:47
     */
    IAudioFocusManager getAudioFocusManager();

    /**
     * 替换音频焦点管理实现
     * @param [IAudioFocusManager] 音频焦点实现
     * @return int status
     * <p>created at 2017/5/09 08:47
     */
    int setAudioFocusManager(IAudioFocusManager impl);

    /**
     * 获取定位服务实现
     * @return ILocationManager 定位接口实现
     * <p>created at 2017/5/09 08:47
     */
    ILocationManager getLocationManager();

    /**
     * 替换定位接口实现
     * @param [ILocationManager] 定位接口实现
     * @return int status
     * <p>created at 2017/5/09 08:47
     */
    int setLocationManager(ILocationManager impl);

    /**
     * 获取录音使能状态管理实现
     * @return IRecordStatusManager 录音使能状态管理实现
     * <p>created at 2017/5/09 08:47
     */
    IRecordStatusManager getRecordStatusManager();

    /**
     * 替换音使能状态管理实现
     * @param [IRecordStatusManager] 录音使能状态管理实现
     * @return int status
     * <p>created at 2017/5/09 08:47
     */
    int setRecordStatusManager(IRecordStatusManager impl);

     /**
      * 替换获取应用市场信息接口
      * @param [IAppStore] 录音使能状态管理实现
      * @return int status
      * <p>created at 2017/8/28 15:43
      */
     int setAppStore(IAppStore impl);

     /**
      * 替换语义解析转换模块
      * @param [INLPProtocolConvert] 语义协议转换业务协议模块实现
      * @return int status
      * <p>created at 2017/8/28 16:38
      */
     int setNLPProtocolConvert(INLPProtocolConvert impl);
}

