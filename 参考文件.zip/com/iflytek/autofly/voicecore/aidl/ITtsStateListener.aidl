package com.iflytek.autofly.voicecore.aidl;

/**
 * tts回调接口
 * @author admin
 *
 */
interface ITtsStateListener {
	
	/**
	 * tts开始合成回调
	 */
    void onTTSPlayBegin(String ttsText);
    
    /**
     * tts合成结束回调
     */
    void onTTSPlayCompleted();
    
    /**
     * tts合成中断回调
     */
    void onTTSPlayInterrupted();
    
    /**
     * tts合成进度回调
     */
    void onTTSProgressReturn(int nTextIndex, int nTextLen);
}
