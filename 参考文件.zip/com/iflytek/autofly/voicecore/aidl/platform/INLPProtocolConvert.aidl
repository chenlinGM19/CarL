// INLPProtocolConverter.aidl
package com.iflytek.autofly.voicecore.aidl.platform;

// Declare any non-default types here with import statements

interface INLPProtocolConvert {
    int onNLP(String focus, String nlp);
}
