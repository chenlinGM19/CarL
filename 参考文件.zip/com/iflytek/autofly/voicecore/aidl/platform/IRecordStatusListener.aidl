// IRecordStatusListener.aidl
package com.iflytek.autofly.voicecore.aidl.platform;

// Declare any non-default types here with import statements

interface IRecordStatusListener {
    void onRecordAvailable(boolean available);
    void onSRAvailable(boolean available);
}
