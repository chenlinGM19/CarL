// IAppStore.aidl
package com.iflytek.autofly.voicecore.aidl.platform;

// Declare any non-default types here with import statements

interface IAppStore {
    String getNLPFocusTarget(String main, String minor);
    String getStatusFocusTarget(String service, String scene);
}
