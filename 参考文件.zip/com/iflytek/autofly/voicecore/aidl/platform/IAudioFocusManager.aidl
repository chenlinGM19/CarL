// IAudioFocusManager.aidl
package com.iflytek.autofly.voicecore.aidl.platform;

// Declare any non-default types here with import statements

interface IAudioFocusManager {

    int requestAudioFocus(int streamType, int durationHint);

    int abandonAudioFocus();
}
