// IRecordStatus.aidl
package com.iflytek.autofly.voicecore.aidl.platform;

import com.iflytek.autofly.voicecore.aidl.platform.IRecordStatusListener;

// Declare any non-default types here with import statements

interface IRecordStatusManager {
    /**
     * 判断当前是否可以录音
     */
    boolean isRecordAvailable();

     /**
      * 判断当前识别是否可用【如电话接听挂断场景识别不可用，但录音可用，需要使用唤醒功能】
      */
    boolean isSrAvailable();

    void registerRecordStatusListener(IRecordStatusListener l);

    void unregisterRecordStatusListener(IRecordStatusListener l);
}
