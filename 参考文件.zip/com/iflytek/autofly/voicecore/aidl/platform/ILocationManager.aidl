// ILocationManager.aidl
package com.iflytek.autofly.voicecore.aidl.platform;

import com.iflytek.autofly.voicecore.aidl.LocationModel;

// Declare any non-default types here with import statements

interface ILocationManager {

    LocationModel getLastLocation();
}
