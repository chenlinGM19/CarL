package com.iflytek.autofly.voicecore.aidl;

/**
 * 识别消息回调接口
 * @author admin
 *
 */
interface ISrListener {
	/**
	 * 识别返回的消息
	 * @param jsonMsg
	 */
	void onSrMessage(long uMsg, long wParam, String lParam);
}
