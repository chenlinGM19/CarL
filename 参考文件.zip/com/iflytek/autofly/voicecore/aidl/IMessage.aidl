// IMessage.aidl
package com.iflytek.autofly.voicecore.aidl;

interface IMessage {
    int onMessage(String main, String minor, in String message);
}
