package com.iflytek.autofly.voicecore.aidl;

/**
 * 录音数据回调接口
 * @author admin
 *
 */
interface IRecListener {
	/**
	 * 录音器返回的数据
	 * @param data 录音数据
	 * @param length 录音数据的长度
	 * @param dataType 音频数据类型
	 */
	void onRecordData(inout byte[] data, int length, int dataType);
	/**
	 * 录音器状态回调接口
	 * @param msgType 录音状态类型
	 */
	void onRecordState(int msgType);
}