package com.iflytek.autofly.voicecore.aidl;
import com.iflytek.autofly.voicecore.aidl.ITtsStateListener;
import com.iflytek.autofly.voicecore.aidl.VoiceServiceId;

/**
 * tts合成调用接口
 * @author admin
 *
 */
interface ITtsSvc {
	
	/**
	 * 创建一个tts实例
	 * @return
	 */
	int createTtsSession(inout VoiceServiceId id, int streamType, ITtsStateListener listener);
	
	/**
	 * 设置tts参数
	 * @param id
	 * @param value
	 * @return
	 */
	int setParam(in VoiceServiceId id, int paramId, int value);
	
	/**
	 * 调用tts合成
	 * @param text
	 * @param iTTSListener
	 * @return
	 */
	int startSpeak(in VoiceServiceId id, String text);

	int startTempSpeak(in VoiceServiceId id, String text, String tempId);

	/**
	 * 暂停tts合成
	 * @return
	 */
	int pauseSpeak(in VoiceServiceId id);
	
	/**
	 * 停止tts合成
	 * @return
	 */
	int stopSpeak(in VoiceServiceId id);
	
	/**
	 * 恢复tts合成
	 * @return
	 */
	int resumeSpeak(in VoiceServiceId id);
	
	/**
	 * 销毁tts实例
	 * @return
	 */
	int destroyTtsSession(in VoiceServiceId id);
}
