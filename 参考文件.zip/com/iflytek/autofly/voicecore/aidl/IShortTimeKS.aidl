package com.iflytek.autofly.voicecore.aidl;
import com.iflytek.autofly.voicecore.aidl.IShortTimeKSListener;
import com.iflytek.autofly.voicecore.aidl.VoiceServiceId;

/**
 * 二次交互服务调用接口
 * @author admin
 *
 */
interface IShortTimeKS {

	/**
	 * 创建二次交互服务实例
	 * @return
	 */
	int create(inout VoiceServiceId id);
	
	/**
	 * 销毁二次交互服务实例
	 * @return
	 */
	int destroy(in VoiceServiceId id);
	
	/**
	 * 二次交互服务参数设置
	 * @param param
	 * @param value
	 * @return
	 */
	int setParam(in VoiceServiceId id, String param, String value);
	
	/**
	 * 二次交互服务关键字设置
	 * @param jsonKeywords
	 * @return
	 */
	int setKeywords(in VoiceServiceId id, String jsonKeywords);

	/**设置可视Activity**/
	int setVisibleActivities(in VoiceServiceId id, String jsonActivities);

	/**
	 * 获取二次交互服务关键字
	 * @return
	 */
	String getKeywords(in VoiceServiceId id);
	
	/**
	 * 开启二次交互服务
	 * @param listener
	 * @return
	 */
	int start(in VoiceServiceId id, IShortTimeKSListener listener);
	
	/**
	 * 停止二次交互服务
	 * @return
	 */
	int stop(in VoiceServiceId id);
	
	/**
	 * 获取当前处于激活状态的二次交互服务id
	 * @return 返回当前VoiceServiceId
	 */
	int activateSkService(in VoiceServiceId id, IShortTimeKSListener listener);
	
	/**
	 * 获取当前处于激活状态的二次交互服务id
	 * @return 返回当前VoiceServiceId
	 */
	int getCurrentSkServiceId(out VoiceServiceId id);
	
	/**
	 * 获取当前处于激活状态的二次交互服务场景
	 * @return 返回当前VoiceServiceId
	 */
	int getCurrentSkServiceScene();
	
	/**
	 * 将结果返回给指定id的服务
	 * @return
	 */
	int onResultReturn(in VoiceServiceId id, String result);

	/**
     * 通过通用搜索搜索匹配keyword条目
     * @return 匹配条目
     */
	String searchMatchItems(String word);


	
}
