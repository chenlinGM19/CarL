package com.iflytek.autofly.voicecore.aidl;

parcelable VoiceServiceId;