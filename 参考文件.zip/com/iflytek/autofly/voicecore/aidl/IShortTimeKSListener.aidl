package com.iflytek.autofly.voicecore.aidl;

/**
 * 二次交互服务回调接口
 * @author admin
 *
 */
interface IShortTimeKSListener {

	/**
	 * 二次交互服务结果返回
	 * @param jsonResult
	 */
	void onResultReturn(String jsonResult);
}
